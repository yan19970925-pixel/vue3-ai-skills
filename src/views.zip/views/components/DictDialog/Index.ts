export interface IQueryPatams {
  dictType: string
  cons?: string // 表查询条件sql语句
  counts?: Number
}
