<template>
  <div class="report">
    <div class="report_con page">
      <div class="title">
        <!-- <div class="title_div">
          <span>体 检 年 份 ：</span>
          <span>{{ jsonData.peVisitListRespVo.year }}</span>
        </div>
        <div class="title_div">
          <span>医 疗 账 号 ：</span>
          <span>{{ jsonData.peVisitListRespVo.medical_no }}</span>
        </div>
        <div class="title_div">
          <span>门 诊 号 ：</span>
          <span>{{ jsonData.peVisitListRespVo.outpatient_card_code }}</span>
        </div> -->
        <div class="position">
          <!-- <div style="font-size: 26px">{{ jsonData.peVisitListRespVo.peId }}</div>
          <div>{{ jsonData.peVisitListRespVo.peId }}</div> -->
          <canvas id="barcodeCanvas"></canvas>
        </div>
      </div>
      <div class="center">
        <div>
          <!-- 军&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;队&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;人&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;员&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;健&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;康&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;体&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;检&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;报&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;告 -->
          {{ jsonData.peVisitListRespVo.hospitalname }}体检报告
        </div>
        <div> 健 康 体 检 报 告 </div>
      </div>
      <div class="info">
        <div class="info_flex">
          <div>姓&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;名：</div>
          <div class="d_border">{{ jsonData.peVisitListRespVo.name }}</div>
        </div>
        <div class="info_flex">
          <div>性&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;别：</div>
          <div class="d_border">{{ jsonData.peVisitListRespVo.sex }}</div>
        </div>
        <div class="info_flex">
          <div>年&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;龄：</div>
          <div class="d_border">{{ jsonData.peVisitListRespVo.age }}</div>
        </div>
        <div class="info_flex">
          <div>联系电话：</div>
          <div class="d_border">{{ jsonData.peVisitListRespVo.phoneNumber }}</div>
        </div>
        <div class="info_flex">
          <div>体检编码：</div>
          <div class="d_border">{{ jsonData.peVisitListRespVo.peId }}</div>
        </div>
        <div class="info_flex">
          <div>参检单位：</div>
          <div class="d_border">{{ jsonData.peVisitListRespVo.unitName }}</div>
        </div>
        <div class="info_flex">
          <div>体检日期：</div>
          <div class="d_border">{{ jsonData.peVisitListRespVo.pePreDate }}</div>
        </div>
        <div class="info_flex">
          <div>单位部门：</div>
          <div class="d_border">{{ jsonData.peVisitListRespVo.print_date }}</div>
        </div>
        <div class="bottom">{{ jsonData.peVisitListRespVo.hospitalname }}</div>
      </div>
      <div
        style="
          width: 100%;
          margin-top: 200px;
          font-size: 14px;
          text-align: center;
          border-top: 1px solid #000;
        "
      >
        <div> 本报告仅供体临床参考，不作为诊断依据，谢谢您的光临！ </div>
      </div>
    </div>
    <!-- <div class="report_jiben hei_1200 page">
      <div class="biaoti">
        <div class="mr_20">{{ jsonData.userJ.branch_hospital_name }}</div>
        <div class="mr_10">体检编号：{{ jsonData.userJ.medical_no }}</div>
        <div class="mr_10">姓名：{{ jsonData.userJ.real_name }}</div>
        <div class="mr_10">性别：{{ jsonData.userJ.sexa }}</div>
        <div class="mr_10">年龄：{{ jsonData.userJ.age }}岁</div>
      </div>
      <div class="qingkuang">基本情况</div>
      <div class="table">
        <table>
          <tr>
            <td class="td_14 td_b bor_t">医疗账号</td>
            <td class="td_28 bor_t" colspan="2">
              {{ jsonData.userJ.archive_no }}
            </td>
            <td class="td_14 td_b bor_t">身份证号</td>
            <td class="td_42 bor_t" colspan="3">
              {{ jsonData.userJ.id_card }}
            </td>
          </tr>
          <tr>
            <td class="td_14 td_b"> 姓&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;名 </td>
            <td class="td_28" colspan="2">{{ jsonData.userJ.real_name }}</td>
            <td class="td_14 td_b"> 性&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;别 </td>
            <td class="td_42" colspan="3">{{ jsonData.userJ.sexa }}</td>
          </tr>
          <tr>
            <td class="td_14 td_b"> 籍&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;贯 </td>
            <td class="td_28" colspan="2">
              {{ jsonData.userJ.birth_place }}
            </td>
            <td class="td_14 td_b"> 民&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;族 </td>
            <td class="td_42" colspan="3">{{ jsonData.userJ.nation }}</td>
          </tr>
          <tr>
            <td class="td_14 td_b">出生日期</td>
            <td class="td_14">{{ jsonData.userJ.birthday }}</td>
            <td class="td_14">入伍时间</td>
            <td class="td_28" colspan="2">
              {{ jsonData.userJ.start_date_of_work }}
            </td>
            <td class="td_14 td_b"> 血&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;型 </td>
            <td class="td_14">{{ jsonData.userJ.blood_type_id }}</td>
          </tr>
          <tr>
            <td class="td_14 td_b">出生地</td>
            <td class="td_14">{{ jsonData.userJ.home_town }}</td>
            <td class="td_28 td_b" colspan="2">隶属大单位</td>
            <td class="td_42" colspan="3">
              {{ jsonData.userJ.top_unit_id }}
            </td>
          </tr>
          <tr>
            <td class="td_14 td_b">婚姻状况</td>
            <td class="td_84" colspan="6">
              {{ jsonData.userJ.marital_status_id }}
            </td>
          </tr>
          <tr>
            <td class="td_14 td_b">人员类别</td>
            <td class="td_84" colspan="6">
              {{ jsonData.userJ.people_type }}
            </td>
          </tr>
          <tr>
            <td class="td_14 td_b">军衔</td>
            <td class="td_84" colspan="6">
              {{ jsonData.userJ.military_rank_id }}
            </td>
          </tr>
          <tr>
            <td class="td_14 td_b">所在地区</td>
            <td class="td_84" colspan="6">
              {{ jsonData.userJ.location_id }}
            </td>
          </tr>
          <tr>
            <td class="td_14 td_b">所属单位</td>
            <td class="td_84" colspan="6">{{ jsonData.userJ.com_no }}</td>
          </tr>
          <tr>
            <td class="td_14 td_b">承检单位</td>
            <td class="td_84" colspan="6">
              {{ jsonData.userJ.branch_hospital_name }}
            </td>
          </tr>
          <tr>
            <td class="td_14 td_b">体检方式</td>
            <td class="td_84" colspan="6">
              {{ jsonData.userJ.exam_method_id }}
            </td>
          </tr>
          <tr>
            <td class="td_14 td_b">联系电话</td>
            <td class="td_84" colspan="6">{{ jsonData.userJ.tel }}</td>
          </tr>
        </table>
      </div>
      <div class="pagination">第{{ 1 }}页/共{{ arrGroupAll.length + 2 }}页</div>
    </div> -->
    <!-- <div class="report_jiben hei_1200 page">
      <div class="biaoti">
        <div class="mr_20">{{ jsonData.userJ.branch_hospital_name }}</div>
        <div class="mr_10">体检编号：{{ jsonData.userJ.medical_no }}</div>
        <div class="mr_10">姓名：{{ jsonData.userJ.real_name }}</div>
        <div class="mr_10">性别：{{ jsonData.userJ.sexa }}</div>
        <div class="mr_10">年龄：{{ jsonData.userJ.age }}岁</div>
      </div>
      <div class="qingkuang">军队人员健康体检心理检测结果</div>
      <div class="table">
        <table style="margin-bottom: 10px">
          <tr>
            <td class="td_48 td_b bor_t" colspan="4">检查医生：张三</td>
            <td class="td_48 td_b bor_t" colspan="4">检查日期：2024-05-15</td>
          </tr>
          <tr>
            <td class="td_12 td_b">序号</td>
            <td class="td_12 td_b">检测项目</td>
            <td class="td_12 td_b">检测结果</td>
            <td class="td_12 td_b">参考值</td>
            <td class="td_24 td_b" colspan="2">检测项目</td>
            <td class="td_12 td_b">人格检测结果</td>
            <td class="td_12 td_b">参考值</td>
          </tr>
          <tr>
            <td class="td_12 td_b">1</td>
            <td class="td_12 td_b">焦虑状态 （Anx-s）</td>
            <td class="td_12 td_b">{{ Anxs }}</td>
            <td class="td_12 td_b">＜0.8</td>
            <td class="td_24 td_b" colspan="2">焦虑性人格（Anx）</td>
            <td class="td_12 td_b">{{ Anx }}</td>
            <td class="td_12 td_b">＜75.0</td>
          </tr>
          <tr>
            <td class="td_12 td_b">2</td>
            <td class="td_12 td_b">自杀意念（Sui-s）</td>
            <td class="td_12 td_b">{{ Suis }}</td>
            <td class="td_12 td_b">＜0.8</td>
            <td class="td_24 td_b" colspan="2">自杀倾向性人格（Sui）</td>
            <td class="td_12 td_b">{{ Sui }}</td>
            <td class="td_12 td_b">＜75.0</td>
          </tr>
          <tr>
            <td class="td_12 td_b">3</td>
            <td class="td_12 td_b">强迫状态（Obs-s）</td>
            <td class="td_12 td_b">{{ Obss }}</td>
            <td class="td_12 td_b">＜0.8</td>
            <td class="td_24 td_b" colspan="2">强迫症性人格（Obs）</td>
            <td class="td_12 td_b">{{ Obs }}</td>
            <td class="td_12 td_b">＜75.0</td>
          </tr>
          <tr>
            <td class="td_12 td_b">4</td>
            <td class="td_12 td_b">抑郁状态（Dep-s）</td>
            <td class="td_12 td_b">{{ Deps }}</td>
            <td class="td_12 td_b">＜0.8</td>
            <td class="td_12 td_b" colspan="2">抑郁性人格（Dep）</td>
            <td class="td_12 td_b">{{ Dep }}</td>
            <td class="td_12 td_b">＜75.0</td>
          </tr>
          <tr>
            <td class="td_12 td_b">5</td>
            <td class="td_12 td_b">精神病状态（Psy-s）</td>
            <td class="td_12 td_b">{{ Psys }}</td>
            <td class="td_12 td_b">＜0.8</td>
            <td class="td_12 td_b" rowspan="3">分裂性人格（Psy）</td>
            <td class="td_12 td_b">神经质（Net）</td>
            <td class="td_12 td_b">{{ Net }}</td>
            <td class="td_12 td_b">＜75.0</td>
          </tr>
          <tr>
            <td class="td_12 td_b">6</td>
            <td class="td_12 td_b">反社会性（Ant-s）</td>
            <td class="td_12 td_b">{{ Ants }}</td>
            <td class="td_12 td_b">＜0.8</td>
            <td class="td_12 td_b">敏感质（Set）</td>
            <td class="td_12 td_b">{{ Sets }}</td>
            <td class="td_12 td_b">＜75.0</td>
          </tr>
          <tr>
            <td class="td_12 td_b">7</td>
            <td class="td_12 td_b">躯体化（Som-s）</td>
            <td class="td_12 td_b">{{ Soms }}</td>
            <td class="td_12 td_b">＜0.8</td>
            <td class="td_12 td_b">分离质（Dit）</td>
            <td class="td_12 td_b">{{ Dit }}</td>
            <td class="td_12 td_b">＜75.0</td>
          </tr>
          <tr>
            <td class="td_12 td_b">8</td>
            <td class="td_12 td_b">睡眠状况（Sle-s）</td>
            <td class="td_12 td_b">{{ Sles }}</td>
            <td class="td_12 td_b">＜0.8</td>
            <td class="td_12 td_b" rowspan="3">反社会性人格（ Ant）</td>
            <td class="td_12 td_b">偏离质（Dev）</td>
            <td class="td_12 td_b">{{ Dev }}</td>
            <td class="td_12 td_b">＜75.0</td>
          </tr>
          <tr>
            <td class="td_12 td_b"></td>
            <td class="td_12 td_b"></td>
            <td class="td_12 td_b"></td>
            <td class="td_12 td_b"></td>
            <td class="td_12 td_b">悖逆质（Ant）</td>
            <td class="td_12 td_b">{{ Ant }}</td>
            <td class="td_12 td_b">＜75.0</td>
          </tr>
          <tr>
            <td class="td_12 td_b"></td>
            <td class="td_12 td_b"></td>
            <td class="td_12 td_b"></td>
            <td class="td_12 td_b"></td>
            <td class="td_12 td_b">冲动质（Imp）</td>
            <td class="td_12 td_b">{{ Imp }}</td>
            <td class="td_12 td_b">＜75.0</td>
          </tr>
        </table>
      </div>
      <div>
        <div>结论：{{ Jjjg }}</div>
      </div>
      <div class="pagination">第{{ 2 }}页/共{{ arrGroupAll.length + 3 }}页</div>
    </div> -->
    <div class="report_jiben hei_1200 page">
      <div class="biaoti">
        <!-- <div class="mr_20">中国人民解放军63710部队医院</div> -->
        <div>体检Id：{{ jsonData.peVisitListRespVo.peId }}</div>
        <div>姓名：{{ jsonData.peVisitListRespVo.name }}</div>
        <div>性别：{{ jsonData.peVisitListRespVo.sex }}</div>
        <div>年龄：{{ jsonData.peVisitListRespVo.age }}岁</div>
        <div>第{{ jsonData.peVisitListRespVo.peVisitId }}次体检</div>
      </div>
      <div class="logo_ti">
        <!-- <img :src="avatar" alt="" /> -->
        <div>{{ jsonData.peVisitListRespVo.hospitalname }}</div>
      </div>
      <div class="back_c">主检报告</div>
      <div class="back_t">体检汇总</div>
      <div class="back_for">
        <div
          class="back_t1"
          v-for="(item1, index1) in jsonData.deptResultItemsRespVoList"
          :key="item1.peDeptCode"
          >{{ index1 + 1 }}、{{ item1.peDeptName ? item1.peDeptName + '：' : ''
          }}{{ item1.content }}</div
        >
        <!-- <div class="back_t1_c">建议控制饮食，加强运动，减轻体重。</div> -->
      </div>
      <div class="jianyi">健康建议</div>
      <div class="jianyi_c" v-for="(item2, index2) in jsonData.guideResultDO" :key="index2">
        <div>{{ index2 + 1 }}、{{ item2.guideTitle }}</div>
        <div :style="jsonData.guideResultDO.length > 10 ? 'font-size:12px;line-height:16px' : ''">
          {{ item2.guideContent }}</div
        >
      </div>
      <!-- <div class="ganxie"></div> -->
      <!-- <div class="ganxie_c">
          我们需要提示您注意的是：本次体检反映的是您当前的健康状况。因人体存在个体生物差异及您选择的检查项目并未涵盖全身所有脏器。因此医生所做的医学诊断和健康状况建议，是依据您的陈述和本次检查的结果综合分析评估而产生的。我们建议您对异常的结果进行相关的进一步检查或跟踪复查。
        </div> -->
      <div class="doc_con">
        <div class="con1">
          <!-- 主检医生： -->
          {{}}</div
        >
        <div class="con1">主审医生：{{ jsonData.peVisitListRespVo.chiefDoctor }}</div>
      </div>
      <div class="doc_con">
        <div class="con1">
          <!-- 主检日期： -->
          {{}}</div
        >
        <div class="con1">主审日期：{{ jsonData.peVisitListRespVo.chiefAuditDate }}</div>
      </div>
      <div class="pagination">第{{ 1 }}页/共{{ arrGroupAll.length + 1 }}页</div>
    </div>
    <div class="report_jiben page" v-for="(itemValue, p) in arrGroupAll" :key="p">
      <div class="biaoti">
        <div>体检Id：{{ jsonData.peVisitListRespVo.peId }}</div>
        <div>姓名：{{ jsonData.peVisitListRespVo.name }}</div>
        <div>性别：{{ jsonData.peVisitListRespVo.sex }}</div>
        <div>年龄：{{ jsonData.peVisitListRespVo.age }}岁</div>
        <div>第{{ jsonData.peVisitListRespVo.peVisitId }}次体检</div>
      </div>
      <div class="jieguo_t" v-if="p === 0">科室检验结果</div>
      <div>
        <div class="jieguo" v-for="(item, i) in itemValue" :key="i">
          <div class="xiaojie" v-if="item[0][0].isSummary && !item[0][0].peItemName">小结</div>
          <div
            class="xiaojie_con"
            v-if="item[0][0]?.isSummaryText && item[0][0].content && !item[0][0].peItemName"
            ><div v-for="(item, ind) in item[0][0].content" :key="ind"> {{ item }}</div>
          </div>
          <div class="jieguo_keshi" v-if="item[0][0].isDeptHead">{{ item[0][0].peDeptName }}</div>
          <div v-for="(itemarr, ir) in item" :key="ir">
            <div v-if="itemarr[0]">
              <div class="jieguo_name" v-if="itemarr[0].isTermHead && itemarr[0].itemAssemName">
                <div class="name1">■{{ itemarr[0].itemAssemName }}</div>
                <div class="name2">检查医生：{{ itemarr[0].doctor }}</div>
                <div class="name3">检查日期：{{ itemarr[0].peResultDate }}</div>
              </div>
            </div>
            <div class="con_table">
              <table class="table">
                <tr v-if="itemarr[0].isTermHead" class="table-header">
                  <td :class="!itemarr[0].isJy ? 'td11' : 'td1'">项目名称</td>
                  <td :class="!itemarr[0].isJy ? 'td22' : 'td2'">检查结果</td>
                  <td class="td3" :style="itemarr[0].isJy ? '' : 'display:none'">提示</td>
                  <td class="td4" :style="itemarr[0].isJy ? '' : 'display:none'">参考范围</td>
                  <td class="td5" :style="itemarr[0].isJy ? '' : 'display:none'">单位</td>
                </tr>
                <tr v-for="(iteminer, ine) in itemarr" :key="ine">
                  <td :class="!itemarr[0].isJy ? 'td11' : 'td1'" v-if="iteminer.peItemName">{{
                    iteminer.peItemName
                  }}</td>
                  <td
                    :class="!itemarr[0].isJy ? 'td22' : 'td2'"
                    v-if="iteminer.peItemName"
                    :style="
                      (iteminer.peResult && iteminer.peResult.length > 36 && !itemarr[0].isJy) ||
                      (iteminer.peResult && iteminer.peResult.length > 10 && itemarr[0].isJy)
                        ? 'font-size:12px;line-height:15px; font-weight: bold;              display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;overflow: hidden;'
                        : ''
                    "
                    >{{ iteminer.peResult }}</td
                  >
                  <td
                    class="td3"
                    v-if="iteminer.peItemName"
                    :style="[
                      itemarr[0].isJy ? {} : { display: 'none' },
                      iteminer.abnormalIndicator == 'H'
                        ? { color: 'red', fontWeight: 'bold' }
                        : iteminer.abnormalIndicator == 'L'
                        ? { color: 'green', fontWeight: 'bold' }
                        : {}
                    ]"
                    >{{
                      iteminer.abnormalIndicator == 'H'
                        ? '⬆ 偏高'
                        : iteminer.abnormalIndicator == 'L'
                        ? '⬇ 偏低'
                        : ''
                    }}</td
                  >
                  <td
                    class="td4"
                    v-if="iteminer.peItemName"
                    :style="itemarr[0].isJy ? '' : 'display:none'"
                    >{{ iteminer.printContext }}</td
                  >
                  <td
                    class="td5"
                    v-if="iteminer.peItemName"
                    :style="itemarr[0].isJy ? '' : 'display:none'"
                    >{{ iteminer.units }}</td
                  >
                </tr>
              </table>
              <div
                class="xiaojie"
                v-if="itemarr[itemarr.length - 1].isSummary && item[0][0].peDeptName !== '检验科'"
                >小结</div
              >
              <div
                class="xiaojie_con"
                v-if="
                  itemarr[itemarr.length - 1]?.isSummaryText &&
                  itemarr[itemarr.length - 1].content &&
                  item[0][0].peDeptName !== '检验科'
                "
                ><div v-for="(item, ind) in itemarr[itemarr.length - 1].content" :key="ind">
                  {{ item }}</div
                >
              </div>
              <!-- <div class="xiaojie_con">{{ itemarr }}</div> -->
            </div>
          </div>
        </div>
      </div>
      <div class="pagination">第{{ p + 2 }}页/共{{ arrGroupAll.length + 1 }}页</div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted, watch } from 'vue'
import JsBarcode from 'jsbarcode'
import { splitStringByWidth } from '@/utils/splitString'
import { propTypes } from '@/utils/propTypes'

const props = defineProps({
  jsonData: {
    type: propTypes.any,
    default: () => ({})
  }
})

const newDeptResultA = ref<any>([])
const arrGroupAll = ref<any>([])

const splitArrayById = (() => {
  const cache = new Map()
  return (arr, idKey) => {
    const key = JSON.stringify(arr.map((item) => item[idKey]))
    if (cache.has(key)) return cache.get(key)

    const result = arr.reduce((acc, cur) => {
      const index = acc.findIndex((item) => item[0][idKey] === cur[idKey])
      index === -1 ? acc.push([cur]) : acc[index].push(cur)
      return acc
    }, [])

    cache.set(key, result)
    return result
  }
})()

const generateBarcode = () => {
  const canvas = document.getElementById('barcodeCanvas') as HTMLCanvasElement
  const peId = props.jsonData?.peVisitListRespVo?.peId
  if (canvas && peId) {
    JsBarcode(canvas, peId, {
      format: 'CODE128',
      displayValue: true,
      fontSize: 14,
      height: 60
    })
  }
}

const processData = () => {
  if (!props.jsonData) return

  const {
    deptResultRespVoList = [],
    deptResultRespVoList1 = [],
    getDeptResultByPeIdGcPrint = [],
    getGcPrintPicZz = [],
    getJyPrint = []
  } = props.jsonData

  if (getJyPrint?.length > 0) {
    getJyPrint.forEach((item) => (item.isJy = true))
  }

  const combinedData = [
    ...deptResultRespVoList,
    ...deptResultRespVoList1,
    ...getDeptResultByPeIdGcPrint,
    ...getGcPrintPicZz,
    ...getJyPrint
  ]

  const groupedByItemAssemName = splitArrayById(combinedData, 'itemAssemName')
  const result = groupedByItemAssemName.map((group) => splitArrayById(group, 'itemAssemName'))

  result.forEach((it, index) => {
    it.forEach((item, k) => {
      if (item.length > 0) {
        item[0].isTermHead = true
        item[item.length - 1].isSummary = true

        item.forEach((g) => {
          g.itemAssemName = item[0].itemAssemName
          if (typeof g.content === 'string') {
            g.content = JSON.parse(`[${JSON.stringify(g.content)}]`)
          } else if (!g.content) {
            g.content = []
          }
        })

        if (k === 0 && item.length) {
          item[0].isDeptHead = true
        }
      }
    })
  })

  newDeptResultA.value = result
  buildPaginationGroups(result)
}

const buildPaginationGroups = (data) => {
  arrGroupAll.value = []
  let pagingGroup: any = []
  let deptGroup: any = []
  let termGroup: any = []
  let newHeight = 0
  let excessSummary: any = []

  const heightLimits = {
    deptHead: 33,
    termHead: 60,
    normal: 30,
    summary: 30
  }

  data.forEach((it, index) => {
    it.forEach((item, m) => {
      item.forEach((k, h) => {
        if (index === 0 && m === 0 && h === 0) newHeight += heightLimits.deptHead

        if (k.isDeptHead) {
          if (newHeight + heightLimits.deptHead > 1150) {
            flushGroups()
            newHeight = heightLimits.deptHead
          } else {
            newHeight += heightLimits.deptHead
          }
        }

        if (k.isTermHead) {
          const itemHeight = heightLimits.termHead
          if (newHeight + itemHeight > 1150) {
            if (k.isDeptHead) {
              termGroup.push({ ...k, isDeptHead: true, isTermHead: true })
              k.isDeptHead = false
            }
            flushGroups()
            newHeight = itemHeight
          } else {
            newHeight += itemHeight
          }
        }

        const projectWidth = splitStringByWidth(k.peItemName, 180)
        const itemHeight = projectWidth?.length > 1 ? heightLimits.termHead : heightLimits.normal

        if (newHeight + itemHeight > 1150) {
          if (k.isTermHead) {
            termGroup.push({ ...k, isDeptHead: true, isTermHead: true })
            k.isTermHead = false
            k.isDeptHead = false
          }
          flushGroups()
          termGroup.push(k)
          newHeight = itemHeight
        } else {
          termGroup.push(k)
          newHeight += itemHeight
        }

        handleSummary(k, heightLimits.summary)
      })

      if (termGroup.length) {
        deptGroup.push(termGroup)
        termGroup = []
      }
    })

    if (deptGroup.length) {
      pagingGroup.push(deptGroup)
      deptGroup = []
    }

    if (index === data.length - 1) {
      if (pagingGroup.length) {
        arrGroupAll.value.push(pagingGroup)
      }
    }
  })

  function flushGroups() {
    if (termGroup.length) {
      deptGroup.push(termGroup)
      termGroup = []
    }
    if (deptGroup.length) {
      pagingGroup.push(deptGroup)
      deptGroup = []
    }
    if (pagingGroup.length) {
      arrGroupAll.value.push(pagingGroup)
      pagingGroup = []
    }
  }

  function handleSummary(k, height) {
    if (excessSummary.length > 0) {
      termGroup[termGroup.length - 1].isSummaryText = true
      termGroup[termGroup.length - 1].content = excessSummary
      excessSummary = []
    }

    if (k.isSummary && k.content?.length > 0) {
      for (let j = 0; j < k.content.length; j++) {
        if (newHeight + height > 1150) {
          if (termGroup.length) {
            if (j === 0) {
              termGroup[termGroup.length - 1].isSummaryText = false
            } else {
              termGroup[termGroup.length - 1].isSummaryText = true
              termGroup[termGroup.length - 1].content = k.content.slice(0, j + 1)
            }
            excessSummary = k.content.slice(j)
            deptGroup.push(termGroup)
            termGroup = []
          }
          flushGroups()
          newHeight = height * excessSummary.length
          break
        } else {
          newHeight += height
          if (termGroup.length) {
            termGroup[termGroup.length - 1].isSummaryText = true
          } else {
            excessSummary = k.content.slice(j)
          }
        }
      }
    }
  }
}

onMounted(() => {
  processData()
  generateBarcode()
})

watch(
  () => props.jsonData,
  () => {
    processData()
    generateBarcode()
  }
)
</script>

<style lang="scss" scoped>
.page {
  page-break-after: always;
}
.report {
  width: 1200px;
  margin: 0 auto;
  font-size: 18px;
  padding: 10px;
  height: 100%;
  overflow: auto;
  background-color: #f1f1f1;
  .report_con {
    background-color: #fff;
    padding: 30px;
    height: 1295px;
    width: 900px;
    margin: 0 auto;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.4);
    /* // border: 1px solid red;
    // border-bottom: 1px solid #000dd;
    // margin-bottom: 10px; */
    .title {
      margin-bottom: 200px;
      position: relative;
      .title_div {
        margin-bottom: 10px;
      }
      .position {
        text-align: center;
        position: absolute;
        top: 15px;
        right: 70px;
      }
    }
    .center {
      width: 100%;
      text-align: center;
      margin-bottom: 300px;
      div {
        margin-bottom: 10px;
        font-weight: bold;
        font-size: 26px;
      }
    }
    .info {
      font-weight: bold;
      margin: 0 auto;

      .info_flex {
        display: flex;
        margin-bottom: 15px;
        justify-content: center;
      }
      .d_border {
        width: 280px;
        padding-left: 50px;
        border-bottom: 1px solid #000;
        box-sizing: border-box;
      }
      .bottom {
        text-align: center;
        margin-top: 50px;
        /* font-size: 24px; */
        /* font-weight: bold; */
      }
    }
  }
  .report_jiben {
    background-color: #fff;
    padding: 30px;
    height: 1295px;
    width: 900px;
    margin: 0 auto;
    margin-top: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.4);
    /* // border: 1px solid red; */
    position: relative;
    .pagination {
      position: absolute;
      bottom: 10px;
      left: 0;
      right: 0;
      text-align: center;
      font-size: 14px;
    }
    .biaoti {
      width: 100%;
      display: flex;
      border-bottom: #000 2px solid;
      box-sizing: border-box;
      margin-bottom: 10px;
      div {
        width: 20%;
        overflow: hidden;
        font-size: 14px;
      }
    }
    .qingkuang {
      width: 100%;
      text-align: center;
      font-size: 22px;
      line-height: 50px;
    }
    .table {
      width: 100%;
      table {
        width: 100%;
        margin-bottom: 80px;
        tr {
          td {
            border-bottom: #000 1px solid;
            border-right: #000 1px solid;
            box-sizing: border-box;
            text-align: center;
            height: 30px;
            line-height: 30px;
            padding: 0;
          }
          td:first-child {
            border-left: #000 1px solid;
            box-sizing: border-box;
          }
        }
        tr:first-child {
          border-top: #000 1px solid;
          box-sizing: border-box;
        }
      }
    }
    .logo_ti {
      position: relative;
      width: 100%;
      height: 70px;
      font-size: 26px;
      display: flex;
      justify-content: center;
      align-items: center;
      text-align: center;
      img {
        width: 60px;
        height: 60px;
        position: absolute;
        left: 0;
      }
    }
    .back_c {
      width: 100%;
      font-size: 22px;
      text-align: center;
      font-weight: bold;
      line-height: 40px;
      background-color: #9fc3e8;
    }
    .back_t {
      width: 100%;
      font-size: 20px;
      margin: 10px 0;
      font-weight: bold;
    }
    .back_for {
      margin-bottom: 20px;
      .back_t1 {
        width: 100%;
        font-size: 18px;
        line-height: 28px;
      }
      .back_t1_c {
        width: 100%;
        font-size: 18px;
        line-height: 28px;
        word-wrap: break-word; /* 允许在单词内换行 */
      }
    }
    .jianyi {
      width: 100%;
      font-size: 22px;
      font-weight: bold;
    }
    .jianyi_c {
      width: 100%;
      height: auto;
      font-size: 18px;
      line-height: 28px;
      word-wrap: break-word; /* 允许在单词内换行 */
    }
    .ganxie {
      width: 100%;
      font-size: 18px;
      line-height: 28px;
    }
    .ganxie_c {
      width: 100%;
      font-size: 18px;
      line-height: 28px;
      word-wrap: break-word; /* 允许在单词内换行 */
      margin-bottom: 40px;
    }
    .doc_con {
      width: 100%;
      display: flex;
      justify-content: flex-end;
      .con1 {
        width: 30%;
        font-weight: bold;
      }
    }
    .jieguo_t {
      width: 100%;
      font-size: 24px;
      text-align: center;
      height: 33px;
      line-height: 33px;
    }
    .jieguo {
      .jieguo_keshi {
        width: 100%;
        font-size: 24px;
        text-align: center;
        height: 33px;
        line-height: 33px;
        border-top: #000 1px solid;
        border-bottom: #000 1px solid;
        box-sizing: border-box;
        font-weight: bold;
        background-color: #9fc3e8;
      }
      .jieguo_name {
        display: flex;
        font-size: 20px;
        height: 30px;
        border-bottom: #000 1px solid;
        box-sizing: border-box;
        background-color: #9fc3e8;
        font-weight: bold;
        div {
          overflow: hidden;
        }
        .name1 {
          width: 45%;
        }
        .name2 {
          width: 25%;
        }
        .name3 {
          width: 30%;
        }
      }
      .con_table {
        .table {
          /* // tr:first-child {
          //   td {
          //     font-weight: bold;
          //   }
          // } */
          .table-header {
            td {
              font-weight: bold;
            }
          }
          tr {
            td {
              height: 30px;
              line-height: 30px;
              text-align: left;
              padding: 0;
            }
            .td1 {
              width: 30%;
            }
            .td2 {
              width: 25%;
            }
            .td3 {
              width: 15%;
            }
            .td4 {
              width: 15%;
            }
            .td5 {
              width: 15%;
            }
            .td11 {
              width: 25%;
            }
            .td22 {
              width: 100%;
            }
          }
        }
      }
      .xiaojie {
        width: 100%;
        font-size: 20px;
        border-bottom: #000 1px solid;
        border-top: #000 1px solid;
        box-sizing: border-box;
        height: 30px;
        line-height: 30px;
      }
      .xiaojie_con {
        div {
          height: 30px;
          line-height: 30px;
          text-align: left;
        }
      }
    }
  }
  .hei_1200 {
    height: 1295px;
    width: 900px;
    margin: 0 auto;
    margin-top: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.4);
    /* // border-bottom: 1px solid #000; */
  }
}
.mr_20 {
  margin-right: 20px;
}
.mr_10 {
  margin-right: 10px;
}
.td_14 {
  width: 14%;
}
.td_28 {
  width: 28%;
}
.td_42 {
  width: 42%;
}
.td_84 {
  width: 84%;
}
.td_b {
  font-weight: bold;
}
.td_12 {
  width: 12%;
}
.td_24 {
  width: 24%;
}
.bor_t {
  border-top: #000 1px solid;
  box-sizing: border-box;
}
</style>
