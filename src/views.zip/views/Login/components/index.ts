import LoginForm from './LoginForm.vue'
import LoginFormTitle from './LoginFormTitle.vue'

export { LoginForm, LoginFormTitle }
