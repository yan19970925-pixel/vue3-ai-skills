export interface AearOptions {
  label: string
  value: string
}
